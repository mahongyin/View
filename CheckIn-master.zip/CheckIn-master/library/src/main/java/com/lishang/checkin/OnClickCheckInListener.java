package com.lishang.checkin;

public interface OnClickCheckInListener {
    void OnClick(int position);
}
